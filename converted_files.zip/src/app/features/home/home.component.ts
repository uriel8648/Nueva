import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

interface Course {
  name: string;
  image: string;
  route: string;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  // Course data that will be displayed in the grid
  courses: Course[] = [
    { name: 'HTML', image: 'assets/images/html.jpeg', route: '/courses/html' },
    { name: 'CSS', image: 'assets/images/css.png', route: '/courses/css' },
    { name: 'JQUERY', image: 'assets/images/jquery.png', route: '/courses/jquery' },
    { name: 'SQL', image: 'assets/images/sql.jpeg', route: '/courses/sql' },
    { name: 'JAVA', image: 'assets/images/java.png', route: '/courses/java' },
    { name: 'JAVASCRIPT', image: 'assets/images/js.png', route: '/courses/javascript' }
  ];

  // Contact form model
  contactForm = {
    name: '',
    email: '',
    subject: '',
    message: ''
  };

  // Flag to show sidebar on mobile
  isSidebarOpen = false;

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Any initialization logic can go here
  }

  /**
   * Navigate to the selected course
   * @param course The course to navigate to
   */
  navigateToCourse(course: Course): void {
    this.router.navigate([course.route]);
  }

  /**
   * Toggle sidebar visibility on mobile devices
   */
  toggleSidebar(): void {
    this.isSidebarOpen = !this.isSidebarOpen;
  }

  /**
   * Close the sidebar
   */
  closeSidebar(): void {
    this.isSidebarOpen = false;
  }

  /**
   * Submit the contact form
   * In a real application, this would call a service to send the form data
   */
  submitContactForm(): void {
    // In a real application, we would call a service to handle the form submission
    console.log('Form submitted:', this.contactForm);
    
    // Reset form after submission
    this.contactForm = {
      name: '',
      email: '',
      subject: '',
      message: ''
    };
    
    // Show success message (in a real app, this would be handled better)
    alert('Thank you for your message! We will get back to you soon.');
  }

  /**
   * Scroll to a specific section of the page
   * @param elementId The ID of the element to scroll to
   */
  scrollToSection(elementId: string): void {
    const element = document.getElementById(elementId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }
}